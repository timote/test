package com.spret.hft.axi;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import quickfix.FieldNotFound;
import quickfix.StringField;
import quickfix.field.NoMDEntries;
import quickfix.field.Symbol;
import quickfix.fix44.ExecutionReport;
import quickfix.fix44.MarketDataIncrementalRefresh;
import quickfix.fix44.MarketDataSnapshotFullRefresh;


/**
 * FIX market data listener for negative currency pair spreads.
 * 
 * @author timppa
 *
 */
public class FixListener implements Runnable {
	
	protected static long startTime = 0;
	private String[] ignoreList = null;
	private Logger logger = LoggerFactory.getLogger(getClass());
	protected volatile boolean running = false;
	protected volatile boolean acknowledged = true;
	protected Thread runner = null;
	protected ConcurrentLinkedQueue<MarketDataSnapshotFullRefresh> fullDataQueue =
			new ConcurrentLinkedQueue<MarketDataSnapshotFullRefresh>();
	protected ConcurrentLinkedQueue<MarketDataIncrementalRefresh> incDataQueue =
			new ConcurrentLinkedQueue<MarketDataIncrementalRefresh>();
	protected ConcurrentLinkedQueue<ExecutionReport> exeReportQueue =
			new ConcurrentLinkedQueue<ExecutionReport>();
	private FixExecutor exe = null;

	protected volatile boolean isSymbolMapReady = false;
	protected Map<String, String> symbolMap = null;
	protected MainProcessor mp = null;

	private Map<String, Double> previousBidMap = null;
	private Map<String, Double> previousAskMap = null;
	
	public FixListener(MainProcessor mp,FixExecutor exe) {
		this.mp = mp;
		if(mp != null) {
			ignoreList = mp.getIgnoreList();
		}
		this.exe = exe;
		previousAskMap = new HashMap<>();
		previousBidMap = new HashMap<>();
	}
	
	public void newMessage(MarketDataSnapshotFullRefresh message) {
		fullDataQueue.add(message);
		synchronized (runner) {
			runner.notify();
		}
	}
	
	public void newMessage(MarketDataIncrementalRefresh message) {
		incDataQueue.add(message);		
		synchronized (runner) {
			runner.notify();
		}
	}
	
	public void newMessage(ExecutionReport report) {
		exeReportQueue.add(report);		
		synchronized (runner) {
			runner.notify();
		}
	}

	public void start() {
		logger.info("Starting.");
		runner = new Thread(this);
		acknowledged = false;
		running = true;
		runner.start();
	}
	
	public void stop() {
		if(!running) {
			logger.error("Already stopped."); 
			return;
		}
		logger.info("Stopping.");
		running = false;
		acknowledged = false;
		synchronized (runner) {
			runner.notify();
		}
		while(!acknowledged) {
			try {
				Thread.sleep(5);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}			
		}
		logger.info("Stopped.");
	}
	
	@Override
	public void run() {
		MarketDataSnapshotFullRefresh fullData = null;
		MarketDataIncrementalRefresh incData = null;	
		NoMDEntries numberOfGroups = new NoMDEntries();
		long marketSnapShotCounter = 0;		
		startTime = System.currentTimeMillis();
		logger.info("FixListener started.");
		logger.info("Waiting for symbol map.");
		//long errorTimeOut = System.currentTimeMillis();
		while(running && !isSymbolMapReady) {
			synchronized (runner) {
				try {
					runner.wait(300);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}				
		}
		symbolMap = mp.getSymbolMap();
		if(symbolMap != null) {
			logger.info("Symbol map received, listening for "+symbolMap.size()+" pairs.");			
		}
		while(running) {
			do {
				try {
					incData = incDataQueue.poll();
					if(incData != null) {
						//logger.info(incData.toString());
						marketSnapShotCounter++;
					}
					fullData = fullDataQueue.poll();
					if(fullData != null) {
						marketSnapShotCounter++;
						fullData.get(numberOfGroups);
						int count = numberOfGroups.getValue();
						if(count <=0) {
							continue;
						}
						PairInfo pi = getMarketData(fullData);
						if(isNegative(pi)) {
							exe.newOrder(pi);
						}
					}		
					//Not using exeReportQueue.
					if(exeReportQueue.size()>0) {
						logger.info("Clearing execution report queue.");
						exeReportQueue.clear();
					}
				} catch(Exception e) {
					logger.error(e.getMessage());
					e.printStackTrace();
					fullData = null;
					incData = null;
				}
				if(System.currentTimeMillis()-startTime >MainProcessor.MESSAGE_PING_TIME_IN_SECONDS*1000) {
					logger.info("Ping! Total market snapshots received: "+marketSnapShotCounter);
					startTime = System.currentTimeMillis();
				}
			} while(fullData != null || incData != null);
			
			if(running) {
				synchronized (runner) {
					try {
						runner.wait(10000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}				
			}
		}
		acknowledged = true;
		logger.info("FixListener ended.");		
	}
	
	public PairInfo getMarketData(MarketDataSnapshotFullRefresh data) {
		String msg = data.toString();
		//logger.info("Data: "+msg);
		//return new PairInfo();
		String tags[] = msg.split("\\0001");
		String f, v;
		PairInfo pi = new PairInfo();	
		String tag = null;
		try {
			StringField timeField = new StringField(MainProcessor.TIMESTAMP_FIELD);
			data.getField(timeField);
			pi.setEntryTime(Long.parseLong(timeField.getValue()));
		} catch (FieldNotFound e) {
			e.printStackTrace();
		}
		for(int i = 0;i<tags.length;i++) {
			if(pi.getSymbol() != null && pi.getAsk() != null && pi.getBid() != null) {
				break;
			}
			tag = tags[i];
			int cut = tag.indexOf("=");
			f = tag.substring(0, cut);
			v = tag.substring(cut+1);
			switch(f) {
			case "55":
				pi.setSymbol(new Symbol(v));
				break;
			case "268":
				int entryCount = Integer.parseInt(v);
				if(entryCount != 2) {
					//logger.info("NoMDEntries is not 2, it is "+entryCount);
					//logger.info("Data: "+msg);
					//hasThree = true;
				}
				break;
			case "269": //Price data, either bid or offer.
				boolean isBid = false;
				String mdEntryType = v;
				if(mdEntryType.endsWith("0")) {
					isBid = true;
				} else if(mdEntryType.endsWith("1")) {
					isBid = false;
				} else {
					logger.error("Cannot get MDEntryType from: "+tags[i]);
					continue;
				}
				
				v = tags[i+1].substring(tags[i+1].lastIndexOf("=")+1);
				if(v.equals("0")) {//Ignore quotes with 0 price.
					logger.info("Ignoring zero price");
					continue;
				}
				//next tag is always the price.
				double mdPrice = Double.parseDouble(v);
				if(isBid) {
					//QuoteEntryID
					if(!tags[i+7].contains("BID1")) {
						pi.setBid(mdPrice);												
					} else {
						//logger.info("Ignoring BID1 price");
					}
				} else {
					if(!tags[i+7].contains("OFFER1")) {
						pi.setAsk(mdPrice);						
					} else {
						//logger.info("Ignoring OFFER1 price");
					}
				}
				break;
			}			
		}
		//if only one sided order book coming.
		String symbolSt = pi.getSymbol().getValue();
		if(pi.getAsk() == null) {
			pi.setAsk(previousAskMap.get(symbolSt));			
		}
		if(pi.getBid() == null) {
			pi.setBid(previousBidMap.get(symbolSt));
		}
		previousBidMap.put(symbolSt, pi.getBid());
		previousAskMap.put(symbolSt, pi.getAsk());
		return pi;
	}

	private boolean isNegative(PairInfo pi) {
		if(pi.getBid() == null|| pi.getAsk() == null) {
			return false;
		}
		BigDecimal bidD = new BigDecimal(pi.getBid());
		BigDecimal askD = new BigDecimal(pi.getAsk());
		BigDecimal diff = bidD.subtract(askD);
		boolean foundNegative = false;
		if(diff.compareTo(MainProcessor.TRADING_THRESHOLD)>=0) {
			String symbol = pi.getSymbol().toString();
			if(ignoreList != null) {
				for(String ignore : ignoreList) {
					if(symbol.contains(ignore)) {
						return foundNegative;
					}
				}
			}
			//5 decimals is the default. 
			if(!symbol.contains("JPY")) {
				logger.info(symbol+" negative: "+pi.getBid()+":"+pi.getAsk());
				foundNegative = true;
			} else { //JPY with 3 decimals
				if(diff.compareTo(MainProcessor.TRADING_JPY_THRESHOLD)>=0) {
					logger.info(symbol+" negative: "+pi.getBid()+":"+pi.getAsk());
					foundNegative = true;
				}
			}
		}
		return foundNegative;
	}
	
	public boolean isSymbolMapReady() {
		return isSymbolMapReady;
	}

	public void setSymbolMapReady(boolean isSymbolMapReady) {
		this.isSymbolMapReady = isSymbolMapReady;
	}
}
