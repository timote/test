'use strict';

angular.module('memberApp')
    .controller('CompetitionsCalendarCtrl', ['$scope', '$rootScope', '$filter', '$state', '$stateParams', '$translate', '$http','SessionService', 'Restangular', 'promiseTracker', '$modal', 'NotificationService', 'Cached',
        function ($scope, $rootScope,  $filter, $state, $stateParams, $translate, $http, SessionService, Restangular, promiseTracker, $modal, NotificationService, Cached) {

            $scope.selectedYear;
            $scope.availableSeasons = getCompetitionSeasons(new Date().getFullYear(), 15);
            $scope.selectedSeason = $scope.availableSeasons[0];
            $scope.membership = SessionService.getCurrentUser().membership;        
            $scope.competitionsTracker = promiseTracker();
            $scope.showDetails = [];
            
            function initMonths() {
                $scope.competitionsByMonth = {
                        1 : [],
                        2 : [],
                        3 : [],
                        4 : [],
                        5 : [],
                        6 : [],
                        7 : [],
                        8 : [],
                        9 : [],
                        10 : [],
                        11 : [],
                        12 : []
                    };            	
            }
            
            initMonths();
            
            if(!$rootScope.ownCompetitionCount) {
            	var today = new Date();
                var from = $filter("date")(today, "yyyy-MM-dd");
                var to = from.substring(0,5)+"12-31";
                var promise = Restangular.all("competition/participation").customGET("",
                        {
                            from : from,
                            to : to
                        })
                .then(function(competitions) {
                	$rootScope.ownCompetitionCount = competitions.length;
                }, function(reason) {
                	//
                });
                $scope.competitionsTracker.addPromise(promise);
            }
                        
            $scope.$watch("selectedSeason", function(season) {
                if(season) {
                	$scope.competitions = true;
                    var from = $filter("date")(season.firstDay, "yyyy-MM-dd");
                    var to = $filter("date")(season.lastDay, "yyyy-MM-dd");
                    initMonths();
                    var promise = Cached.getCached(getCompetitionsCacheKey(from, to), function() {
                        return Restangular.all("competition").customGET("",
                            {
                                from : from,
                                to : to
                            });
                    }).then(function(competitions) {
                       $scope.selectedYear = season.year;
                       makeList(competitions);
                       $rootScope.competitionCount = competitions.length;
                   	   $scope.competitions = false;
                    }, function(reason) {
                      	  $scope.competitions = false;
                    });
                    $scope.competitionsTracker.addPromise(promise);
                }
            }, true);
            
            function getCompetitionsCacheKey(startDate, endDate) {
                return "cs-" + startDate + "-" + endDate;
            }
            
            $scope.doNothing = function() {
            }
            
            $scope.openCompetition = function (competitionId, selectedYear) {
            	var cId = competitionId;
            	$state.go("main.competitions.info", {competitionId : cId, selectedYear: selectedYear});
            };

            function makeList(competitions) {  
                competitions.forEach(function (competition) {
                    var start = $filter("parseDateString")(competition.startTime);
                    var month = start.getMonth() + 1;
                    var participationStart = null;
                    var participationEnd = null;                     
                    if(competition.participationStartDate) {
                    	participationStart = $filter("parseDateString")(competition.participationStartDate);
                    }                    
                    if(competition.participationEndDate) {
                    	participationEnd = $filter("parseDateString")(competition.participationEndDate);                    	
                    }
                    
                    var today =  new Date().getTime();                    
                    var canParticipate = competition.open;
                    
                    if(competition.participationEndDate) {
                        competition.participationTimeEnded =  participationEnd.getTime() < today;                        
                    }
                    
                    if(canParticipate) {                    	
                    	canParticipate = competition.canParticipate;
                    } else {
                    	competition.invitationOnly = true;
                    }
                    
                    if(canParticipate && competition.participationStartDate && competition.participationEndDate) {
                        competition.participationTimeNow =  
                        	today > participationStart.getTime() && today < participationEnd.getTime()
                    }
                    
                    /*	
                	 * 	Integer CALENDAR = new Integer(10);
        				Integer SINGLE = new Integer(1);
        				Integer TEAM = new Integer(2);
        				Integer TEAM_SPECIAL = new Integer(3);
        				Integer CUP = new Integer(4);
        				Integer TEAM_GREENSOME = new Integer(5);
        				Integer TEAM_FOURSOME = new Integer(6);
        				Integer TEAM_SCRAMBLE = new Integer(7);
        				Integer SINGLE_ECLECTIC = new Integer(8);
                	 */
                    competition.isTeamCompetition = (competition.competitionType == 2 || 
                    		competition.competitionType == 3 || 
                    		competition.competitionType == 5 ||
                    		competition.competitionType == 6 || 
                    		competition.competitionType == 7)
                    
                    switch(competition.competitionType) {
                    	case 2:
                        	competition.competitionTypeName = $translate.instant("competitions.teamCompetition");
                        	break;
                    	case 3:
                        	competition.competitionTypeName = 'Best Ball';
                        	break;
                    	case 4:
                           	competition.competitionTypeName = 'Cup';
                            break;
                    	case 5:
                           	competition.competitionTypeName = 'Greensome';
                        	break;
                    	case 6:
                           	competition.competitionTypeName = 'Foursome';
                        	break;
                    	case 7:
                           	competition.competitionTypeName = 'Scramble';
                        	break;
                    	case 8:
                           	competition.competitionTypeName = 'Eclectic';
                        	break;	
                    }
                    		
                    if (competition.canParticipate) {
                        checkParticipation(competition);
                    }
                    $scope.competitionsByMonth[month].push(competition);                                        	
                });
                
                var d = new Date();
                var year = d.getFullYear();
                var monthNumber = d.getMonth()+1;
                for(var i = 1; i<=12;i++) {
        			$scope.showDetails[i] = false;   
        			if($scope.selectedYear == year) {
                    	if(i >= monthNumber) {
                    		if($scope.competitionsByMonth[i] && $scope.competitionsByMonth[i].length>0) {
                    			$scope.showDetails[i] = true;
                    		} 
                    	}        				
        			} else {
        				$scope.showDetails[i] = true;
        			}
                }
            }
            
            function checkParticipation(competition) {
                var from = competition.startTime.substring(6);
                var promise2 = Restangular.all("competition/participation").customGET("",
                        {
                            from : from,
                            to : from
                        }).then(function(participations) {
                        	competition.isParticipating = participations.find(function(participation) { return participation.competition.id == competition.id });
                        	if(competition.isParticipating) {
                            	competition.canParticipate = false;                        		
                        	}
                        }, function(reason) {
                        	competition.canParticipate = false;
                        });
                $scope.competitionsTracker.addPromise(promise2);                                
            }
            
            function getCompetitionSeasons(startingYear, count) {
                var seasons = [];
                for(var year = startingYear; year > (startingYear - count); year--) {
                    var season = {
                        year : year,
                        firstDay : new Date(year, 0, 1),
                        lastDay : new Date(year, 11, 31),
                        label : $translate.instant("profile.stats-history", {number : year})
                    };
                    seasons.push(season);
                }
                return seasons;
            }
        }]);