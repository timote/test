package com.tt.javasas;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;

import com.tt.javasas.utils.DataFileReader;
import com.tt.javasas.utils.HashProcessor;
import com.tt.javasas.vo.DataEntry;
import com.tt.javasas.vo.DataResult;

/**
 * Starter class of this project.
 * 
 * @author timppa
 *
 */
public class MainProcessor {
	
	private static Logger log = Logger.getGlobal();

	public static void main(String[] args) throws IOException {
		if(args.length != 2) {
			System.out.println("Give config file and incident data text file.");
			System.out.println("Example:");
			System.out.println("./src/test/resources/db.cfg ./src/test/resources/input_data.txt");
			return;
		}
		DataFileReader dfr = new DataFileReader();
		DataProcessor dp = new DataProcessor();
		DBProcessor dbp = new DBProcessor();
		HashProcessor hp = new HashProcessor();
		
		log.info("------------------------------------------------------------------");
		log.info("Incident data processor started.");
		log.info("Config file: "+args[0]);
		log.info("Input file: "+args[1]);
		
		Properties props = new Properties();
		props.load(new FileInputStream(new File(args[0])));
		String dbUrl = props.getProperty("db_url");
		String dbUser = props.getProperty("db_user");
		String dbPwd = props.getProperty("db_password");
		log.info("Database URL: "+dbUrl);
		log.info("Database user: "+dbUser);
		if(dbPwd == null) {
			log.severe("Database password cannot be empty!");
			return;
		}
		
		//Read data entries from file.
		List<DataEntry> entryList = null;		
		entryList = dfr.readFile(args[1]);			
		if(entryList.isEmpty()) {
			log.info("Nothing to process in the file. Program aborted.");
			return;
		}
		
		//get hash codes.
		for(DataEntry entry : entryList) {
			String text = entry.toString();
			String hash = hp.getSHA256(text);
			entry.setHashCode(hash);
		}
		
		//Calculate values for each data entry
		List<DataResult> resultList = dp.processDataEntries(entryList);
		
		//Insert into database tables.
		dbp.openDatabase(dbUrl, dbUser, dbPwd);
		dbp.insertNewData(resultList);
		log.info("Program completed.");
	}

}
