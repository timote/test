Here are code samples from various projects I have done.
Timo Tervola

