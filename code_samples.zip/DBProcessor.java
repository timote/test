package com.ftw;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import org.sql2o.Connection;
import org.sql2o.Sql2o;

import com.ftw.vo.Address;
import com.ftw.vo.Author;
import com.ftw.vo.AuthorPrWeb;
import com.ftw.vo.Book;
import com.ftw.vo.BookStore;
import com.ftw.vo.InteliusHit;
import com.ftw.vo.SearchParams;

/**
 * MySQL based crawler database processor.
 * 
 * @author timppa
 *
 */
public class DBProcessor {

	private Sql2o sql2o;
	private Logger logger = Logger.getLogger(this.getClass().getSimpleName());
	private HashMap<String, Integer> bookStoreIdMap = null;
	
	/**
	 * Open Sql2o library connection to database. No need to close it later.
	 * 
	 * @param url
	 * @param user
	 * @param password
	 */
	public void openDatabase(String url, String user, String password) {
		sql2o = new Sql2o(url, user, password);
		loadBookStoreMap();			
	}

	/**
	 * Load book store map.
	 * 
	 */
	private void loadBookStoreMap() {
		bookStoreIdMap = new HashMap<>();
		String selectSql = "select bookstore_id, name, description, home_url from ftw_bookstores";
		List<BookStore> list = null;
		try (Connection con = sql2o.open()) {
			list = con.createQuery(selectSql)
					.addColumnMapping("bookstore_id", "id")
					.addColumnMapping("home_url", "url")
					.executeAndFetch(BookStore.class);
			con.close();
		}
		for(BookStore bs: list) {
			logger.info("Adding bookstore to id map: "+bs.toString());
			bookStoreIdMap.put(bs.getName(), bs.getId());
		}		
	}

	/**
	 * Check whether author is already in the database.
	 * 
	 * @param website
	 * @param shortBioHash
	 * @return
	 * @throws IOException
	 */
	public boolean checkAuthorHash(String website, String shortBioHash) throws IOException {
		if(!bookStoreIdMap.containsKey(website)) {
			throw new IOException("Bookstore: "+website+" not in database table ftw_bookstores");
		}
		Integer id = bookStoreIdMap.get(website);
		String selectSql = "select author_hash from ftw_authors where bookstore_id=:id and author_hash=:hash";
		List<String> list = null;
		try (Connection con = sql2o.open()) {
			list = con.createQuery(selectSql)
					.addParameter("id", id)
					.addParameter("hash", shortBioHash)
					.executeAndFetch(String.class);
			con.close();
		}
		return (list != null && list.size()>0) ? true : false;
	}

	/**
	 * Check whether link has been processed already.
	 * 
	 * @param website
	 * @param hashUrl
	 * @return
	 * @throws IOException
	 */
	public boolean isProcessedLink(String website, String hashUrl) throws IOException {
		if(!bookStoreIdMap.containsKey(website)) {
			throw new IOException("Bookstore: "+website+" not in database table ftw_bookstores");
		}
		Integer id = bookStoreIdMap.get(website);
		String selectSql = "select link_hash from ftw_crawled_links where bookstore_id=:id "
				+ "and link_hash=:hash";
		List<String> list = null;
		try (Connection con = sql2o.open()) {
			list = con.createQuery(selectSql)
					.addParameter("id", id)
					.addParameter("hash", hashUrl)
					.executeAndFetch(String.class);
			con.close();
		}
		return (list != null && list.size()>0) ? true : false;
	}
	
	/**
	 * Insert processed book link hash into ftw_crawled_links.
	 * 
	 * @param website
	 * @param hashUrl
	 * @throws IOException
	 */
	public void insertLink(String website, String hashUrl) throws IOException {
		if(!bookStoreIdMap.containsKey(website)) {
			throw new IOException("Bookstore: "+website+" not in database table ftw_bookstores");
		}
		Integer id = bookStoreIdMap.get(website);
		String insertSql = "insert into ftw_crawled_links (bookstore_id, link_hash) "
				+ "values(:id, :hash)";
		try (Connection con = sql2o.open()) {
			con.createQuery(insertSql)
					.addParameter("id", id)
					.addParameter("hash", hashUrl)
					.executeUpdate();
			con.close();
		}		
	}

	/**
	 * Process new author.
	 * 
	 * @param website
	 * @param author
	 * @throws IOException 
	 */
	public void insertAuthor(String website, Author author) throws IOException {
		Integer authorId = getAuthorId(author);
		if(authorId != null) {
			author.setAuthorId(authorId);
			logger.info("Author already in the database, skipping.");
			return;
		}
		if(!bookStoreIdMap.containsKey(website)) {
			throw new IOException("Bookstore: "+website+" not in database table ftw_bookstores");
		}
		Integer id = bookStoreIdMap.get(website);
		
		logger.info(author.getFirstName()+" "+author.getMiddleNames()+" "+author.getLastName());
		String insertSql = "insert into ftw_authors(bookstore_id, author_hash, first_name, "
				+ "middle_names, surname, bio, bio_short) "
				+ "values(:id, :hash, :first, :middles, :last, :bio, :bioShort)";
		try (Connection con = sql2o.open()) {				
			con.createQuery(insertSql)
				.addParameter("id", id)
				.addParameter("hash", author.getHashKey())
				.addParameter("first", author.getFirstName())
				.addParameter("middles", author.getMiddleNames())
				.addParameter("last", author.getLastName())
				.addParameter("bio", author.getBio())
				.addParameter("bioShort", author.getShortBio())
				.executeUpdate();
			con.close();
		}
	}
	
	/**
	 * Insert Prweb related author contact info.
	 * 
	 * @param apw
	 * @throws IOException
	 */
	public void insertAuthorPrWeb(AuthorPrWeb apw) throws IOException {
		
		logger.info("Inserting author prweb info: "+apw.getContactInfo());
		String deleteSql = "delete from ftw_authors_prweb_info where author_id=:authorId";
		String insertSql = "insert into ftw_authors_prweb_info "
				+ "(author_id, contact_info, email_contact_link, author_website) "
				+ "values(:authorId, :contactInfo, :emailContactLink, :authorWebsite)";
		try (Connection con = sql2o.open()) {				
			con.createQuery(deleteSql).bind(apw).executeUpdate();
			con.createQuery(insertSql).bind(apw).executeUpdate();
			con.close();
		} catch(Exception e) {
			throw new IOException(e);
		}
	}
	
	/**
	 * Get author id based on hash key.
	 * @param author
	 * @return
	 */
	public Integer getAuthorId(Author author) {
		String selectSql = "select author_id from ftw_authors where author_hash=:hash";
		List<Integer> list = null;
		try (Connection con = sql2o.open()) {
			list = con.createQuery(selectSql)
					.addParameter("hash", author.getHashKey())
					.executeAndFetch(Integer.class);
			con.close();
		}
		if(list != null && list.size()>0) {
			return list.get(0);			
		}
		return null;
	}
	
	/**
	 * Insert book info.
	 * @param website
	 * @param book
	 * @throws IOException
	 */
	public void insertBook(String website, Book book) throws IOException {

		if(!bookStoreIdMap.containsKey(website)) {
			throw new IOException("Bookstore: "+website+" not in database table ftw_bookstores");
		}
		Integer id = bookStoreIdMap.get(website);
		Integer bookId = getBookId(book.getUrlHash());
		Integer authorId = getAuthorId(book.getAuthor());
		if(bookId != null) {
			logger.info("Skipping book already in the database: "+book.getTitle());
			return;
		}
		
		String insertSql = "insert into ftw_books (bookstore_id, author_id, isbn, title, "
				+ "url, url_hash, description, short_description, pages, categories, "
				+ "image_url, image_file) "
				+ "values(:bookStoreId, :authorId, :isbn, :title, :url, :urlHash, "
				+ ":desc, :shortDesc, :pages, :categories, :imageUrl, :imageFileName)";
		try (Connection con = sql2o.open()) {
			con.createQuery(insertSql)
			.addParameter("bookStoreId", id)
			.addParameter("authorId", authorId)
			.addParameter("isbn", book.getCode())
			.addParameter("title", book.getTitle())
			.addParameter("url", book.getUrl())
			.addParameter("urlHash", book.getUrlHash())
			.addParameter("desc", book.getDesc())
			.addParameter("shortDesc", book.getShortDesc())
			.addParameter("pages", book.getLength())
			.addParameter("categories", book.getCategories())
			.addParameter("imageUrl", book.getImageUrl())
			.addParameter("imageFileName", book.getImageFileName())
			.executeUpdate();
			con.close();
		} 
		if(book.getFormats() == null) {
			return;
		}		
		bookId = getBookId(book.getUrlHash());
		
		insertSql = "insert into ftw_book_prices (book_id, format, currency, price) "
				+ "values(:bookId, :format, :currency, :price)";
		String formats[] = book.getFormats();
		float prices[] = book.getPrices();
		for(int i = 0; i<formats.length;i++) {
			try (Connection con = sql2o.open()) {
				con.createQuery(insertSql)
				.addParameter("bookId", bookId)
				.addParameter("format", formats[i])
				.addParameter("currency", "USD")
				.addParameter("price", prices[i])
				.executeUpdate();
				con.close();
			}
		}
	}
	
	/**
	 * Get book id.
	 * @param hashUrl
	 * @return
	 */
	private Integer getBookId(String hashUrl) {
		String selectId = "select book_id from ftw_books where url_hash=:hash";		
		List<Integer> list = null;
		try (Connection con = sql2o.open()) {
			list = con.createQuery(selectId)
					.addParameter("hash", hashUrl)
					.executeAndFetch(Integer.class);
			con.close();
		}
		if(list != null && list.size()>0) {
			return list.get(0);
		} else {
			return null;
		}

	}

	/**
	 * Get new authors without Calais info
	 * @return
	 */
	public List<Author> getNewAuthors() {
		
		String selectSql = "select author_id, author_hash, first_name, middle_names, surname, bio "
				+ "from ftw_authors where bio_calais_json is null";
		List<Author> list = null;
		try (Connection con = sql2o.open()) {
			list = con.createQuery(selectSql)
					.addColumnMapping("author_id", "authorId")
					.addColumnMapping("author_hash", "hashKey")
					.addColumnMapping("first_name", "firstName")
					.addColumnMapping("middle_names", "middleNames")
					.addColumnMapping("surname", "lastName")
					.executeAndFetch(Author.class);
			con.close();
		}
		return list;
	}


	/**
	 * Get list of new searches for Intelius.
	 * 
	 * @param limit
	 * @return
	 */
	public List<SearchParams> getNewSearches(int limit) {
		String selectSql = "select * from ftw_author_intelius_params where search_done=false limit :limit";
		List<SearchParams> list = null;
		try (Connection con = sql2o.open()) {
			list = con.createQuery(selectSql)
					.addParameter("limit", limit)
					.addColumnMapping("search_param_id", "searchParamId")
					.addColumnMapping("author_id", "authorId")
					.addColumnMapping("search_params", "searchParams")
					.addColumnMapping("search_done", "searchDone")
					.addColumnMapping("updated", "updated")
					.executeAndFetch(SearchParams.class);
			con.close();
		}
		return list;
	}	
	
	/**
	 * Save into database search parameters and results. 
	 * 
	 * @param author
	 */
	public void saveSearch(Author author) {
		Integer searchParamId = getSearchParamId(author);
		Integer authorId = author.getAuthorId();		
		updateAuthor(author);
		
		if(searchParamId == null) { //new search.
			//insert search params to table with search_done set to false.
			String insertSqlSearchParams = "insert into ftw_author_intelius_search_params "
					+ "(author_id, search_params, search_done) "
					+ "values(:authorId, :searchParams, :searchDone)";
			
			try (Connection con = sql2o.open()) {
				con.createQuery(insertSqlSearchParams)
						.addParameter("authorId", authorId)
						.addParameter("searchParams", author.getIntelliusSearch())
						.addParameter("searchDone", false)
						.executeUpdate();
				con.close();
			}					
			searchParamId = getSearchParamId(author);
		} else {
			//Delete first all previous search results if any.		
			String deleteSqlAddr = "delete from ftw_author_intelius_addresses where search_param_id=:id";
			String deleteSqlEmails = "delete from ftw_author_intelius_emails where search_param_id=:id";
			String deleteSqlPhones = "delete from ftw_author_intelius_phones where search_param_id=:id";
			String deleteSqlHits = "delete from ftw_author_intelius_hits where search_param_id=:id";
			try (Connection con = sql2o.open()) {
				con.createQuery(deleteSqlAddr)
					.addParameter("id", searchParamId)
					.executeUpdate();
				con.createQuery(deleteSqlEmails)
					.addParameter("id", searchParamId)
					.executeUpdate();
				con.createQuery(deleteSqlPhones)
					.addParameter("id", searchParamId)
					.executeUpdate();
				con.createQuery(deleteSqlHits)
					.addParameter("id", searchParamId)
					.executeUpdate();
				con.close();
			}
		}
		
		//Insert search matches one by one, using the searchParamId as key to the tables.
		String insertSqlHit = "insert into ftw_author_intelius_hits "
				+ "(search_param_id, hit_number, full_name, age, nothing_found) "
				+ "values(:id, :hitNumber, :fullName, :age, :nothingFound)";
		int hitNumber = 0;
		InteliusHit[] rList = author.getResultHits();
		if(rList == null || rList.length==0) {			
			try (Connection con = sql2o.open()) {
				con.createQuery(insertSqlHit)
						.addParameter("id",searchParamId)
						.addParameter("hitNumber", hitNumber)
						.addParameter("fullName", "")
						.addParameter("age", -1)
						.addParameter("nothingFound", true)
						.executeUpdate();
				con.close();
			}		
			logger.info("Saving nothing-found-entry for search params: "+author.getIntelliusSearch());
			return;
		}
		
		String insertSqlPhone = "insert into ftw_author_intelius_phones "
				+ "(search_param_id, hit_number, phone) values(:id, :hitNumber, :phone)";
		String insertSqlEmails = "insert into ftw_author_intelius_emails "
				+ "(search_param_id, hit_number, email) values(:id, :hitNumber, :email)";		
		String insertSqlAddress = "insert into ftw_author_intelius_addresses "
				+ "(address_number, search_param_id, hit_number, address, zip, "
				+ "city, us_state, country) "
				+ "values(:number, :id, :hitNumber, :address, :zip, :city, :state, :country)";
		for(InteliusHit ih: rList) {
			logger.info("Inserting to database: "+ih.toString());
			if(ih.getAge().contains("Deceased")) {
				ih.setAge("-1");
			}
			try (Connection con = sql2o.open()) {
				con.createQuery(insertSqlHit)
						.addParameter("id",searchParamId)
						.addParameter("hitNumber", hitNumber)
						.addParameter("fullName", ih.getName())
						.addParameter("age", !ih.getAge().equals("N/A") ? ih.getAge() : "0")
						.addParameter("nothingFound", false)
						.executeUpdate();
				//insert phones, emails, addresses.
				String emails[] = ih.getEmails();
				if(emails != null) {
					for(String e : emails) {
						con.createQuery(insertSqlEmails)
						.addParameter("id",searchParamId)
						.addParameter("hitNumber", hitNumber)
						.addParameter("email", e.trim())
						.executeUpdate();						
					}
				}
				Address addresses[] = ih.getParsedAddresses();
				if(addresses != null) {
					int addrCount = 1;
					for(Address addr : addresses) {
						//:number, :id, :hitNumber, :address, :zip, :city, :state, :country
						con.createQuery(insertSqlAddress)
							.addParameter("number",addrCount)
							.addParameter("id",searchParamId)
							.addParameter("hitNumber", hitNumber)
							.addParameter("address", addr.getStreet())
							.addParameter("zip", addr.getZip())
							.addParameter("city", addr.getCity())
							.addParameter("state", addr.getState())
							.addParameter("country", addr.getCountry())
							.executeUpdate();	
						addrCount++;
					}
				}
				String phones[] = ih.getPhones();
				if(phones != null) {
					for(String p : phones) {
						con.createQuery(insertSqlPhone)
						.addParameter("id",searchParamId)
						.addParameter("hitNumber", hitNumber)
						.addParameter("phone", p)
						.executeUpdate();												
					}
				}
				con.close();
			} catch(Exception e) {
				logger.severe(ih.toString());
				logger.severe(e.getMessage());
			}
			hitNumber++;
		}
		
		//put search_done to true in the main search table.
		String updateSqlSearchDone = "update ftw_author_intelius_search_params set search_done=true "
				+ "where search_param_id=:id";
		try (Connection con = sql2o.open()) {
			con.createQuery(updateSqlSearchDone)
					.addParameter("id",searchParamId)
					.executeUpdate();
			con.close();
		}
	}

	/**
	 * Save search results as error.
	 * 
	 * @param author
	 */
	public void saveSearchError(Author author) {
		updateAuthor(author);
	}
	
	/**
	 * Update author with Calais info and Intelius search result status.
	 * 
	 * @param author
	 */
	private void updateAuthor(Author author) {
		//update first ftw_authors info.
		String otherLoc = "";
		//take first other location.
		if(author.getLocations()!= null && author.getLocations().length>0) {
			otherLoc =author.getLocations()[0];
		}
		String authorWebsite = "";
		if(author.getUrls() != null && author.getUrls().length>0) {
			authorWebsite = author.getUrls()[0];
		}
		String email = "";
		if(author.getEmails() != null && author.getEmails().length>0) {
			email = author.getEmails()[0];
		}
		String updateSqlAuthor = "update ftw_authors set bio_calais_json=:cl, "
				+ "primary_location=:pr, other_location=:other, email=:el, website=:ws, "
				+ "error_msg=:error, updated=CURRENT_TIMESTAMP where author_id=:id";
		if(author.getCalaisBio() == null) {
			logger.info("No Calais data, setting to N/A");
			author.setCalaisBio("N/A");
		}
		logger.info("Calais JSON data length:"+author.getCalaisBio().length());
		if(author.getCalaisBio().length()>65400) {
			logger.info("Cutting Calais JSON data to 65400 chars.");
			String cb = "JSON too large, cut to 65400 chars:"+
					author.getCalaisBio().substring(0,65400);
			author.setCalaisBio(cb);
		}
		try (Connection con = sql2o.open()) {
			con.createQuery(updateSqlAuthor)
					.addParameter("cl",author.getCalaisBio())
					.addParameter("pr",author.getPrimaryLocation())
					.addParameter("other", otherLoc)
					.addParameter("el", email)
					.addParameter("ws", authorWebsite)
					.addParameter("error",author.getErrorMsg())
					.addParameter("id",author.getAuthorId())
					.executeUpdate();
			con.close();
		} catch(Exception e) {
			logger.severe(e.getMessage());
			throw e;
		}
	}
	
	private Integer getSearchParamId(Author author) {
		Integer searchParamId = null;
		String selectSqlSearchId = "select search_param_id from ftw_author_intelius_search_params "
				+ "where author_id=:authorId and search_params=:searchParams";
		List<Integer> list = null;
		try (Connection con = sql2o.open()) {
			list = con.createQuery(selectSqlSearchId)
					.addParameter("authorId", author.getAuthorId())
					.addParameter("searchParams", author.getIntelliusSearch())
					.executeAndFetch(Integer.class);
			con.close();
		}
		if(list.size()>0) {
			searchParamId = list.get(0);
		}
		return searchParamId;
	}
	
}
